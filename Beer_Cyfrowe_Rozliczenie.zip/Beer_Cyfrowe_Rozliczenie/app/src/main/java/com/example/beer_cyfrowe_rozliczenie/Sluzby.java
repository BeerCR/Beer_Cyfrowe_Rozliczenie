package com.example.beer_cyfrowe_rozliczenie;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class Sluzby extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sluzby);
    }
}